<?php

return array(
	'maxsum' => array(
		'value'        => '',
		'title'        => 'Максимальная сумма оплаты',
		'description'  => 'Максимальная сумма оплаты при которой отображается модуль.',
		'control_type' => 'input',
		'class'        => 'js-maxsum-kassa',
	)
);