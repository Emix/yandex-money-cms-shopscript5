<?php
return array(
    'name'        => 'Яндекс.Деньги (Y.CMS)',
    'description' => 'Платежный сервис «<a href="http://money.yandex.ru">Яндекс.Деньги</a>»',
    'icon'        => 'img/yandexmoney16.png',
    'logo'        => 'img/kassa-logo.png',
    'vendor'      => 'webasyst',
    'version'     => '1.2.4',
);
