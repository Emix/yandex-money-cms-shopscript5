<?php
return array(
    'view' => array('waSmarty3View', array(
        'left_delimiter' => '{{',
        'right_delimiter' => '}}',
    )),
);