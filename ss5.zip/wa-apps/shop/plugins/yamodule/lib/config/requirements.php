<?php

return array(    
    'php.curl'=>array(
        'name'=>'cURL',
        'description'=>'Обмен данными со сторонними серверами',
        'strict'=>true,
   )
);


