<?php
return array(
	'yamodule/price.xml' => array(
		'plugin' => 'yamodule',
		'module' => 'frontend',
		'action' => 'market',
	),
	'pokupki/cart' => array(
		'plugin' => 'yamodule',
		'module' => 'frontend',
		'action' => 'pcart',
	),
	'pokupki/order/<type>' => array(
		'plugin' => 'yamodule',
		'module' => 'frontend',
		'action' => 'porder',
	),
	'metrika/cart/info' => array(
		'plugin' => 'yamodule',
		'module' => 'frontend',
		'action' => 'cartinfo',
	),
);
