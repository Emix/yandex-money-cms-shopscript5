<?php
return array(
    'name'        => 'Яндекс.Деньги',
    'description' => 'Платежная система «<a href="http://money.yandex.ru">Яндекс.Деньги</a>»',
    'icon'        => 'img/yandexmoney16.png',
    'logo'        => 'img/yandexmoney.png',
    'vendor'      => 'webasyst',
    'version'     => '1.1.0',
);
